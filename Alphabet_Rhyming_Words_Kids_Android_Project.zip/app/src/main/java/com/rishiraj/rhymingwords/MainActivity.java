package com.rishiraj.rhymingwords;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.ToneGenerator;
import android.media.AudioManager;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, choices;
    TextView letter, word, question, scoreText, levelText, feedback;
    int score=0, level=1, index=0;
    ToneGenerator tone;
    String[][] data = {
        {"A","CAT","BAT","DOG","SUN","CAR"},
        {"B","BEE","TREE","CAR","SUN","DOG"},
        {"C","CAT","HAT","PIG","BUS","FOX"},
        {"D","DOG","FOG","CAT","SUN","BEE"},
        {"E","HEN","PEN","CAR","DOG","FOX"},
        {"F","FAN","MAN","PIG","BUS","CAT"},
        {"G","GOAT","BOAT","HEN","FOX","SUN"},
        {"H","HEN","PEN","DOG","CAT","BUS"},
        {"I","PIG","WIG","SUN","CAR","DOG"},
        {"J","JAR","CAR","HEN","FOX","PIG"},
        {"K","KING","RING","DOG","CAT","SUN"},
        {"L","LOG","FROG","PEN","BUS","HEN"},
        {"M","MOON","SPOON","CAT","DOG","FOX"},
        {"N","NEST","BEST","PIG","CAR","SUN"},
        {"O","FOX","BOX","CAT","HEN","BUS"},
        {"P","PIG","WIG","DOG","CAR","SUN"},
        {"Q","QUEEN","GREEN","CAT","FOX","BUS"},
        {"R","RAIN","TRAIN","DOG","PIG","CAT"},
        {"S","SUN","FUN","HEN","CAR","FOX"},
        {"T","TOP","MOP","DOG","PIG","CAT"},
        {"U","CUP","PUP","FOX","HEN","BUS"},
        {"V","VAN","CAN","DOG","PIG","CAT"},
        {"W","WALL","BALL","FOX","HEN","SUN"},
        {"X","BOX","FOX","CAT","DOG","PIG"},
        {"Y","YELL","BELL","SUN","CAR","DOG"},
        {"Z","ZOO","BLUE","CAT","HEN","PIG"}
    };

    public void onCreate(Bundle b){
        super.onCreate(b);
        tone=new ToneGenerator(AudioManager.STREAM_MUSIC,80);
        build();
        loadQuestion();
    }

    TextView tv(String s,int size){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.rgb(35,35,55));
        t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(12,12,12,12);
        return t;
    }

    void build(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,24,24,24); root.setBackgroundColor(Color.rgb(247,248,255));
        setContentView(root);

        TextView title=tv("🔤 Rhyming Words Kids",25);
        title.setTextColor(Color.rgb(70,65,170));
        root.addView(title,new LinearLayout.LayoutParams(-1,70));

        LinearLayout info=new LinearLayout(this);
        info.setGravity(Gravity.CENTER);
        levelText=tv("Level 1",16); scoreText=tv("⭐ 0",16);
        info.addView(levelText,new LinearLayout.LayoutParams(0,60,1));
        info.addView(scoreText,new LinearLayout.LayoutParams(0,60,1));
        root.addView(info);

        letter=tv("A",48); letter.setTextColor(Color.rgb(255,120,70));
        root.addView(letter,new LinearLayout.LayoutParams(-1,85));
        word=tv("CAT",30);
        root.addView(word,new LinearLayout.LayoutParams(-1,65));

        question=tv("Which word rhymes with CAT?",20);
        root.addView(question,new LinearLayout.LayoutParams(-1,75));

        choices=new LinearLayout(this); choices.setOrientation(LinearLayout.VERTICAL);
        root.addView(choices,new LinearLayout.LayoutParams(-1,0,1));

        feedback=tv("",18); root.addView(feedback,new LinearLayout.LayoutParams(-1,55));

        TextView dev=tv("Made by Rishi Raj Yadav",13);
        dev.setTextColor(Color.GRAY); root.addView(dev,new LinearLayout.LayoutParams(-1,45));
    }

    void loadQuestion(){
        if(index>=data.length){ index=0; level++; }
        String[] q=data[index];
        letter.setText(q[0]); word.setText(q[1]);
        question.setText("Which word rhymes with "+q[1]+"?");
        levelText.setText("Level "+level);
        feedback.setText("");
        choices.removeAllViews();

        ArrayList<String> opts=new ArrayList<>();
        opts.add(q[2]); opts.add(q[3]); opts.add(q[4]); opts.add(q[5]);
        Collections.shuffle(opts);

        for(String s:opts){
            Button btn=new Button(this);
            btn.setText(s);
            btn.setTextSize(21);
            btn.setAllCaps(false);
            btn.setTextColor(Color.rgb(45,45,60));
            btn.setBackgroundColor(Color.WHITE);
            btn.setOnClickListener(v -> check((Button)v, s.equals(q[2])));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,0,1);
            lp.setMargins(0,6,0,6);
            choices.addView(btn,lp);
        }
    }

    void check(Button b, boolean correct){
        if(correct){
            score+=10;
            feedback.setText("🎉 Great job! Correct!");
            feedback.setTextColor(Color.rgb(30,150,75));
            tone.startTone(ToneGenerator.TONE_PROP_BEEP,120);
        } else {
            feedback.setText("💡 Try again!");
            feedback.setTextColor(Color.rgb(210,80,60));
            tone.startTone(ToneGenerator.TONE_PROP_NACK,120);
            return;
        }
        scoreText.setText("⭐ "+score);
        for(int i=0;i<choices.getChildCount();i++) choices.getChildAt(i).setEnabled(false);
        new Handler().postDelayed(() -> { index++; loadQuestion(); },650);
    }

    @Override protected void onDestroy(){
        if(tone!=null) tone.release();
        super.onDestroy();
    }
}
