# Alphabet Rhyming Words Kids

Android learning game for children.

## Features
- A-Z alphabet
- Rhyming word questions
- Four choices
- Score and levels
- Offline gameplay
- Simple sound feedback
- Child-friendly portrait UI
- Developer: Rishi Raj Yadav

## Build with GitHub Actions
1. Create a GitHub repository.
2. Upload all files while keeping the folder structure.
3. Push to `main`.
4. Open **Actions**.
5. Open **Build Rhyming Words APK and AAB**.
6. Download the generated APK/AAB from Artifacts.

The debug APK is ready for phone testing. The release AAB produced here is unsigned and must be signed before Play Store publishing.
