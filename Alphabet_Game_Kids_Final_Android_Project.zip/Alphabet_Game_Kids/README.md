# Alphabet Game Kids
A child-friendly A-Z learning and find-the-letter game.

Features: A-Z, picture illustrations, words, Text-to-Speech, quiz choices, score/stars, APK/AAB GitHub Actions build.
Developer: Rishi Raj Yadav
