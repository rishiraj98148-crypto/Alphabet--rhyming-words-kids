package com.rishiraj.alphabetgame;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.speech.tts.TextToSpeech;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    LinearLayout root, answers;
    TextView letterView, wordView, scoreView, feedbackView;
    ImageView imageView;
    TextToSpeech tts;
    final Random random = new Random();
    int current, score = 0;
    final String[] letters={"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
    final String[] words={"Apple","Ball","Cat","Dog","Elephant","Fish","Grapes","Hat","Ice Cream","Juice","Kite","Lion","Moon","Nest","Orange","Penguin","Queen","Rabbit","Sun","Tiger","Umbrella","Van","Whale","Xylophone","Yo-Yo","Zebra"};
    final int[] pics={R.drawable.a_apple,R.drawable.b_ball,R.drawable.c_cat,R.drawable.d_dog,R.drawable.e_elephant,R.drawable.f_fish,R.drawable.g_grapes,R.drawable.h_hat,R.drawable.i_icecream,R.drawable.j_juice,R.drawable.k_kite,R.drawable.l_lion,R.drawable.m_moon,R.drawable.n_nest,R.drawable.o_orange,R.drawable.p_penguin,R.drawable.q_queen,R.drawable.r_rabbit,R.drawable.s_sun,R.drawable.t_tiger,R.drawable.u_umbrella,R.drawable.v_van,R.drawable.w_whale,R.drawable.x_xylophone,R.drawable.y_yoyo,R.drawable.z_zebra};

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g; }
    TextView tv(String s,float size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setGravity(Gravity.CENTER); t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setTextColor(Color.rgb(35,35,55)); return t; }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(255,247,230));
        getWindow().setNavigationBarColor(Color.rgb(255,247,230));
        tts=new TextToSpeech(this,this);
        build();
        nextQuestion();
    }

    void build(){
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16),dp(10),dp(16),dp(12));
        root.setBackgroundColor(Color.rgb(255,247,230));
        scroll.addView(root);
        setContentView(scroll);

        LinearLayout header=new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=tv("🔤 Alphabet Game",24);
        title.setTextColor(Color.rgb(83,67,180));
        scoreView=tv("⭐ 0",18);
        header.addView(title,new LinearLayout.LayoutParams(0,dp(54),1));
        header.addView(scoreView,new LinearLayout.LayoutParams(dp(85),dp(54)));
        root.addView(header);

        TextView prompt=tv("Find the letter!",21);
        prompt.setTextColor(Color.rgb(55,55,75));
        root.addView(prompt,new LinearLayout.LayoutParams(-1,dp(42)));

        letterView=tv("A",50);
        letterView.setTextColor(Color.rgb(238,91,70));
        root.addView(letterView,new LinearLayout.LayoutParams(-1,dp(60)));

        FrameLayout card=new FrameLayout(this);
        card.setPadding(dp(8),dp(8),dp(8),dp(8));
        card.setBackground(bg(Color.WHITE,30));
        imageView=new ImageView(this);
        imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        card.addView(imageView,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,0,1);
        cp.setMargins(0,dp(4),0,dp(6));
        root.addView(card,cp);

        wordView=tv("Apple",25);
        wordView.setTextColor(Color.rgb(43,143,80));
        root.addView(wordView,new LinearLayout.LayoutParams(-1,dp(45)));

        Button hear=new Button(this);
        hear.setText("🔊  Hear it");
        hear.setTextSize(17); hear.setAllCaps(false);
        hear.setTextColor(Color.rgb(65,55,125));
        hear.setBackground(bg(Color.rgb(239,236,255),26));
        hear.setOnClickListener(v->speak());
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(48));
        hp.setMargins(0,dp(3),0,dp(4));
        root.addView(hear,hp);

        feedbackView=tv("",16);
        root.addView(feedbackView,new LinearLayout.LayoutParams(-1,dp(38)));

        answers=new LinearLayout(this);
        answers.setOrientation(LinearLayout.HORIZONTAL);
        answers.setGravity(Gravity.CENTER);
        root.addView(answers,new LinearLayout.LayoutParams(-1,dp(66)));

        TextView dev=tv("Made by Rishi Raj Yadav",12);
        dev.setTextColor(Color.GRAY);
        root.addView(dev,new LinearLayout.LayoutParams(-1,dp(28)));
    }

    void nextQuestion(){
        current=random.nextInt(26);
        letterView.setText(letters[current]);
        wordView.setText(words[current]);
        imageView.setImageResource(pics[current]);
        feedbackView.setText("");
        answers.removeAllViews();

        ArrayList<Integer> options=new ArrayList<>();
        options.add(current);
        while(options.size()<4){ int n=random.nextInt(26); if(!options.contains(n)) options.add(n); }
        Collections.shuffle(options);

        for(int n:options){
            Button b=new Button(this);
            b.setText(letters[n]); b.setTextSize(21); b.setAllCaps(false);
            b.setTextColor(Color.rgb(55,55,75)); b.setBackground(bg(Color.WHITE,20));
            b.setOnClickListener(v->answer(n==current));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(58),1);
            p.setMargins(dp(3),dp(3),dp(3),dp(3));
            answers.addView(b,p);
        }
        new Handler().postDelayed(this::speak,250);
    }

    void answer(boolean correct){
        if(correct){
            score+=10; scoreView.setText("⭐ "+score);
            feedbackView.setText("🎉 Great! Correct!");
            feedbackView.setTextColor(Color.rgb(35,145,75));
            for(int i=0;i<answers.getChildCount();i++) answers.getChildAt(i).setEnabled(false);
            new Handler().postDelayed(this::nextQuestion,850);
        }else{
            feedbackView.setText("💡 Try again!");
            feedbackView.setTextColor(Color.rgb(210,85,65));
        }
    }

    void speak(){
        if(tts!=null) tts.speak(letters[current]+". "+words[current],TextToSpeech.QUEUE_FLUSH,null,"alphabet");
    }
    @Override public void onInit(int status){ if(status==TextToSpeech.SUCCESS) speak(); }
    @Override protected void onDestroy(){ if(tts!=null){tts.stop();tts.shutdown();} super.onDestroy(); }
}
