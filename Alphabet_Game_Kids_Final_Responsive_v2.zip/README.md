# Alphabet Game Kids — Responsive Final

Version 2.0 responsive kids alphabet game.
- A-Z learning
- Large colorful picture cards
- Find-the-letter quiz
- Text-to-speech
- Score and stars
- Responsive layout for Android phones
- Developer: Rishi Raj Yadav
